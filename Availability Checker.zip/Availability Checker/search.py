from tkinter import *
from PIL import Image,ImageTk
from tkinter import messagebox
import mysql.connector
win=Tk()
f1=('Microsoft Yahei UI Light',15)
path = Image.open("proj9.jpg")
resized = path.resize((1550,800),Image.ANTIALIAS)
new_pic = ImageTk.PhotoImage(resized)
img = Label(win,image=new_pic)
img.place(x=0,y=0)

frame1 =Frame(win,bg="white",width=400,height=500)
frame1.pack(pady=30)
path1 = Image.open("proj2.jpg")
resized1 = path1.resize((500,450),Image.ANTIALIAS)
new_pic1 = ImageTk.PhotoImage(resized1)
img1 = Label(win,image=new_pic1)
img1.place(x=650,y=300)

#  frame2= Frame(frame1,bg="white",width=300,height=500)
#  frame2.pack(pady=20,padx=20)



l1=Label(win,text="Search City",font=f1,fg='firebrick1')
l1.place(x=500,y=50)
t1=Entry(win,bd=2,font=f1)
t1.place(x=700,y=50)




win.geometry("1600x1600")
win.resizable(False,False)
win.mainloop()