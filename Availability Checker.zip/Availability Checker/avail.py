import tkinter as tk
from tkinter import *
from tkinter import ttk
from PIL import Image,ImageTk
from tkinter import messagebox
import mysql.connector

root = tk.Tk()

f1=('Microsoft Yahei UI Light',15)


class Window :

    def __init__(self,master):
        
        def demo():
            s1=t1.get();
            if s1=="":
                messagebox.showinfo("Warning.","Please Enter Cityname")
                return

            
            mydb = mysql.connector.connect(
            user="root",
            password="",
            host="localhost",
            port="3307",
            database="my_proj"
            )
            mycur = mydb.cursor() 
            
            var2 = "select city from district_table where city = '"+s1+"'"
            mycur.execute(var2)
            mycur.fetchall()
            if mycur.rowcount<=0:
                messagebox.showinfo("Warning.","Not Found")
                return

            # def zomato():
            #     print("True")
            #     var3 = "select city,zomato from zomato where city In (select city from district_table where ='"+s1+"')"
            #     mycur.execute(var2)
            #     mycur.fetchall()
            #     print(var3)
            #     messagebox.showinfo("Warning.","Please Enter Cityname")
            #     return
                
        

        frame1 =Frame(root,bg="white",width=440,height=450)
        frame1.pack(pady=120,padx=170)
        frame1.place(x=550,y=200)

        l1=Label(root,text="Search City",font=("Helvetica"),fg='black')
        l1.place(x=560,y=300)
        t1=Entry(root,bd=2,font=f1)
        t1.place(x=700,y=300)
        b1=Button(root,text="🔎",font=f1,bg='#D2D2D2',command=demo)
        b1.place(x=930,y=290)

        var = tk.StringVar()
        options_menu = ttk.OptionMenu(master,var,"Categories")
        options_menu.pack(padx=150,pady=150)
        options_menu.place(x=650,y=380)

        menu = options_menu["menu"]
        sublist1 = tk.Menu(menu,tearoff=False)
        menu.add_cascade(label="Food",menu=sublist1)
        sublist1.add_command(label="Zomato")
        sublist1.add_command(label="Swiggy",command=lambda:var.set("Swiggy"))

        sublist2 = tk.Menu(menu,tearoff=False)
        menu.add_cascade(label="Travel",menu=sublist2)
        sublist2.add_command(label="Ola",command=lambda:var.set("Ola"))
        sublist2.add_command(label="Uber",command=lambda:var.set("Uber"))
        sublist2.add_command(label="City Buses",command=lambda:var.set("City Buses"))
        sublist2.add_command(label="Airport",command=lambda:var.set("Airport"))
        sublist2.add_command(label="Railway Station",command=lambda:var.set("Railway Station"))




  
path = Image.open("proj8.jpg")
resized = path.resize((1530,800),Image.ANTIALIAS)
new_pic = ImageTk.PhotoImage(resized)
img = Label(root,image=new_pic)
img.place(x=0,y=0)
# frame1 =Frame(root,bg="white",width=450,height=550)
# frame1.pack(pady=150,padx=100)  



root.geometry("1600x1600")
window = Window(root)
root.mainloop()











# win = tkinter.Tk()
# f1=('Microsoft Yahei UI Light',15)

# win.title("Search Here...")
# win.geometry("1600x1600")
# options_list=["Food","Travel"]
# value_inside=tkinter.StringVar(win)
# value_inside.set("Select an Option")

# question_menu=tkinter.OptionMenu(win,value_inside, *options_list)
# question_menu.config(width=30,height=2,font=f1)
# question_menu.grid(row=0,column=0,padx=600,pady=150,sticky='nsew')

# def info():
#     if value_inside1=='Food':
        
#         value_inside1=tkinter.StringVar()
#         value_inside1.set("Select food delivery type")
#         question_menu1=tkinter.OptionMenu(win,value_inside1, "Zomato","Swiggy")
#         question_menu1.config(width=30,height=2,font=f1)
#         question_menu1.grid(row=0,column=0,padx=600,pady=150,sticky='nsew')
    




# def print_ans():
#     print("Selected Option:{}".format(value_inside.get()))
#     return None

# def print_ans1():
#     print("Selected Option:{}".format(value_inside1.get()))
#     return None



