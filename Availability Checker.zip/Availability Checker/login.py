from tkinter import *
from tkinter import ttk
from PIL import Image,ImageTk
from tkinter import messagebox
import mysql.connector



win=Tk()
win.title("Login Page")
f1=('Microsoft Yahei UI Light',15)

path = Image.open("proj9.jpg")
resized = path.resize((1530,800),Image.ANTIALIAS)
new_pic = ImageTk.PhotoImage(resized)
img = Label(win,image=new_pic)
img.place(x=0,y=0)

frame1 =Frame(win,bg="white",width=450,height=500)
frame1.pack(pady=150,padx=100)

def back():
    win.destroy()
    import home

def avail1():
    win.destroy()
    import avail1

def login():   
    s1=t1.get();
    s2=t2.get();
    
    if s1=="":
        messagebox.showinfo("Warning.","Please Enter Username")
        return
    if s2=="":
        messagebox.showinfo("Warning.","Please Enter Password")
        return
    mydb = mysql.connector.connect(
        user="root",
        password="",
        host="localhost",
        port="3307",
        database="my_proj"
    )

    mycur = mydb.cursor()
    var1 = "select username,password from register where username='"+s1+"' and password="+s2
    mycur.execute(var1)
    mycur.fetchall()
    # print(mycur.rowcount)
    if mycur.rowcount>0:
        mycur.execute( 
            "insert into login values('"+s1+"',"+s2+")"
        )
        messagebox.showinfo("Warning.","Login Successfully")
        avail1()
        mydb.commit()        
        
    else:
       
        messagebox.showwarning("Warning.","Not found")
        return
       

heading = Label(win, text="  Login  ", font=("Helvetica",26,"bold"), bg='White', fg='Black')
heading.place(x=710, y=210)

l1=Label(win,text="Username",font=("Helvetica"),fg='Black')
l1.place(x=560,y=320)
t1=Entry(win,bd=2,font=f1)
t1.place(x=750,y=320)

l2=Label(win,text="Password",font=("Helvetica"),fg='Black')
l2.place(x=560,y=390)
t2=Entry(win,bd=2,font=f1,show='*')
t2.place(x=750,y=390)

b1=Button(win,text="Login",font=("Courier",18,"bold"),bg='medium orchid',command=login)
b1.place(x=810,y=525)
b2=Button(win,text="Back",font=("Courier",17,"bold"),bg='medium orchid',command=back)
b2.place(x=640,y=525)

win.geometry("1600x1600")
win.mainloop()


